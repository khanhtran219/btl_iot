import React, { useState } from 'react';
import { Routes, Route } from 'react-router-dom';
import './App.css';
import Sidebar from './components/Sidebar';
import Dashboard from './pages/Dashboard';

function App() {
    const [state, setState] = useState(false);
    const [tcCard, setTcCard] = useState(null);
    const [ktcCard, setKtcCard] = useState(null);
    const [mode, setMode] = useState(false);
    const [relay, setRelay] = useState([]);

    return (
        <div className="App flex justtify-around">
            <div className="w-[20%]">
                <Sidebar />
            </div>
            <div className="w-[80%]">
                <Routes>
                    <Route
                        path="/"
                        element={
                            <Dashboard
                                tcCard={tcCard}
                                setTcCard={setTcCard}
                                ktcCard={ktcCard}
                                setKtcCard={setKtcCard}
                                mode={mode}
                                setMode={setMode}
                                state={state}
                                setState={setState}
                            />
                        }
                    />
                </Routes>
            </div>
        </div>
    );
}

export default App;
