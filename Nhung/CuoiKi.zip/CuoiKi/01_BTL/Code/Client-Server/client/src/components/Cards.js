import React, { useEffect, useState } from 'react';
import io from 'socket.io-client';

const Cards = ({
    tcCard,
    setTcCard,
    ktcCard,
    setKtcCard,
}) => {
    const [showWarningTc, setShowWarningTc] = useState(false);
    const [showWarningKtc, setShowWarningKtc] = useState(false);

    useEffect(() => {
        const socket = io('http://localhost:8688');

        socket.on('taiche', (data) => {
            setTcCard(data);
            checkWarning(data, 'tc');
        });

        socket.on('khongtaiche', (data) => {
            setKtcCard(data);
            checkWarning(data, 'ktc');
        });

        return () => {
            socket.disconnect();
        };
    }, [setTcCard, setKtcCard]);

    const checkWarning = (percentage, type) => {
        if (percentage > 80) {
            if (type === 'tc') {
                setShowWarningTc(true);
            } else if (type === 'ktc') {
                setShowWarningKtc(true);
            }
        } else {
            if (type === 'tc') {
                setShowWarningTc(false);
            } else if (type === 'ktc') {
                setShowWarningKtc(false);
            }
        }
    };

    return (
        <div className="flex justify-around">
            <div style={{ backgroundColor: '#FFD9E6' }} className="mr-[35px] w-[50%] h-[150px] rounded-xl bg-clip-border text-gray-700 shadow-md border">
                <div className="mt-2 mb-3 ml-[3px] text-sm text-neutral-700 bg-clip-border">Rác tái chế</div>
                <div className="flex mr-[20px] justify-around items-center rounded-xl bg-clip-border text-gray-700">
                    <img
                        src="https://cdn.tgdd.vn/Files/2020/11/20/1308209/sacpintreniphone6_1120x630-800-resize.jpg"
                        className={`object-contain h-[75px] mr-[-50px]`}
                    />
                    <div className="ml-[70px]">
                        <p className="mb-3 text-base text-neutral-1000">Phần trăm</p>
                        <h5 className="mb text-xl font-medium leading-tight text-neutral-800">
                            {tcCard}  %
                        </h5>
                    </div>
                </div>
                {showWarningTc && <div className="mt-[5px] text-red-500 font-bold text-sm">Cảnh báo: Thùng rác đã đầy</div>}
            </div>
            <div style={{ backgroundColor: '#D0E9FF'}} className="mr-[30px] w-[50%] h-[150px] rounded-xl bg-clip-border text-gray-700 shadow-md border">
                <div className="mt-2 mb-3 ml-[3px] text-sm text-neutral-1000 bg-clip-border">Rác không tái chế</div>
                <div className="flex mr-[20px] justify-around items-center rounded-xl bg-clip-border text-gray-700">
                    <img
                        src="https://cdn.tgdd.vn/Files/2020/11/20/1308209/sacpintreniphone6_1120x630-800-resize.jpg"
                        className={`object-contain h-[75px] mr-[-50px]`}
                    />
                    <div className="ml-[70px]">
                        <p className="mb-3 text-base text-neutral-600">Phần trăm</p>
                        <h5 className="mb text-xl font-medium leading-tight text-neutral-800">
                            {ktcCard}  %
                        </h5>
                    </div>
                </div>
                {showWarningKtc && <div className="mt-[5px] text-red-500 font-bold text-sm">Cảnh báo: Thùng rác đã đầy</div>}
            </div>
        </div>
    );
};

export default Cards;
