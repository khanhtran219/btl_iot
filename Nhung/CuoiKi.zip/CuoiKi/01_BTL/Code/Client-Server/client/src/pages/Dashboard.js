import React, { useState } from 'react';
import Cards from '../components/Cards';
import Lid from '../components/lid';
import TrashCan from '../components/TrashCan';


const Dashboard = ({
    tcCard,
    setTcCard,
    ktcCard,
    setKtcCard,
    state,
    setState,
    mode,
    setMode
}) => {
    
    return (
        <div >
            { }
            <hr className="mr-[100px]" />

            <div className="mt-[40px] mr-[120px] flex justify-around items-center">
                <div className="w-[60%]">
                    <Cards
                        tcCard={tcCard}
                        setTcCard={setTcCard}
                        ktcCard={ktcCard}
                        setKtcCard={setKtcCard}
                    />
                </div>
            </div>

            <div className="mt-[40px] mr-[180px] flex justify-around items-center">
                <div className="w-[0px]">
                <Lid
                    state={state}
                    setState={setState}
                />
                </div>
                <div>
                <TrashCan
                    mode={mode}
                    setMode={setMode}
                />
                </div>
            </div>
            
        </div>
    );
};

export default Dashboard;
