import React, { useEffect } from 'react';
import io from 'socket.io-client';

const TrashCan = ({
    mode,
    setMode

}) => {
    const socket = io('http://localhost:8688');

    useEffect(() => {

        socket.on('mode', (data) => {
            setMode(data);
        });
        return () => {
            socket.disconnect();
        };
    }, []);

    const handleTurnOnMode = () => {
        setMode(true);
        socket.emit('control_relay_2', 1);
    };

    const handleTurnOffMode = () => {
        setMode(false);
        socket.emit('control_relay_2', 0);
    };


    return (
        <div className="flex flex-col justify-around">
            <div className="ml-[30px]  mt-[50px] mb-[40px] flex w-[300px] justify-around items-center rounded-xl bg-white bg-clip-border text-gray-700 shadow-md border h-[150px]">
                {mode ? (
                    <img
                        src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQaEODUx6Wn33-mGX6NE94cN7mP1DKoZmhwfw&usqp=CAU"
                        className="object-contain h-[100px] mr-[-100px]"
                        alt="TrashCan is on"
                    />
                ) : (
                    <img
                        src="https://www.ludlowkingsley.com/files/normal_97152.png"
                        className="object-contain h-[100px] mr-[-100px]"
                        alt="TrashCan is off"
                    />
                )}
                <div className="ml-[90px]">
                    <div>
                        <button
                            className={`mr-2 mt-[0.3rem] w-[80px] h-[35px] rounded-[0.4375rem] ${mode
                                ? 'bg-primary text-white'
                                : 'bg-neutral-300 text-black'
                                } focus:outline-none focus:ring-2 focus:ring-primary`}
                            onClick={
                                mode
                                    ? handleTurnOffMode
                                    : handleTurnOnMode
                            }
                        >
                            {mode ? 'ON' : 'OFF'}
                        </button>
                    </div>
                </div>
            </div>

        </div>
    );
};

export default TrashCan;
