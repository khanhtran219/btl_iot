import React, { useEffect } from 'react';
import io from 'socket.io-client';

const Lid = ({
    state,
    setState,

}) => {
    const socket = io('http://localhost:8688');

    useEffect(() => {
        
        socket.on('napthung', (data_received) => {
            setState(data_received);
        });
        return () => {
            socket.disconnect();
        };
    }, []);

    const handleTurnOn = () => {
        setState(true);
        socket.emit('control_relay_1', 1);
    };

    const handleTurnOff = () => {
        setState(false);
        socket.emit('control_relay_1', 0);
    };


    return (
        <div className="flex flex-col justify-around">
            <div className="ml-[30px]  mt-[50px] mb-[40px] flex w-[300px] justify-around items-center rounded-xl bg-white bg-clip-border text-gray-700 shadow-md border h-[150px]">
                {state ? (
                    <img
                        src="https://media.istockphoto.com/id/972734014/vi/anh/th%C3%B9ng-r%C3%A1c-th%E1%BA%A3i-nh%E1%BB%B1a.jpg?s=612x612&w=0&k=20&c=-G6j3BOCZ2jskfULf5mR1tcfAxevdmrg6l3qmlyJ6iA="
                        className="object-contain h-[100px] mr-[-100px]"
                        alt="Lid is on"
                    />
                ) : (
                    <img
                        src="https://www.ajproducts.ie/globalassets/149813.jpg?ref=F72F25B489"
                        className="object-contain h-[100px] mr-[-100px]"
                        alt="Lid is off"
                    />
                )}
                <div className="ml-[-50px]">
                    <div>
                        <button
                            className={`mr-2 mt-[0.3rem] w-[80px] h-[35px] rounded-[0.4375rem] ${state
                                ? 'bg-primary text-white'
                                : 'bg-neutral-300 text-black'
                                } focus:outline-none focus:ring-2 focus:ring-primary`}
                            onClick={
                                state
                                    ? handleTurnOff
                                    : handleTurnOn
                            }
                        >
                            {state ? 'ON' : 'OFF'}
                        </button>
                    </div>
                </div>
            </div>

        </div>
    );
};

export default Lid;
