const express = require('express');
const mqtt = require('mqtt');
const app = express();
const port = 8688;
const bodyParser = require('body-parser');
const cors = require('cors');
const mysql = require('mysql2');

//const dbConn = require('./config/dbConn');

app.use(cors());

app.use(bodyParser.urlencoded({ extended: true }));//
app.use(bodyParser.json());
app.use('/data', express.static('data'));

const server = require('http').Server(app);
const io = require('socket.io')(server, {
    cors: {
        origin: 'http://localhost:3000',
    },
});

server.listen(port);


var client = mqtt.connect('mqtt://broker.hivemq.com');
client.on('connect', function () {
    console.log('mqtt connected');
    client.subscribe('PTIT/IoTN1/servo');
    client.subscribe('PTIT/IoTN1/dulieu');
});

client.on('message', function (topic, message) {
    if (topic == 'PTIT/IoTN1/dulieu') {
        const data = JSON.parse(message);
        io.emit('napthung', data.napthung);
        io.emit('mode', data.mode);
        io.emit('taiche', data.taiche);
        io.emit('khongtaiche', data.khongtaiche);
        console.log(data.taiche, data.khongtaiche, data.napthung, data.mode);
    }
});

io.on('connection', function (socket) {
    socket.on('control_relay_1', function (state1) {
        if (state1 == '1') {
            client.publish('PTIT/IoTN1/servo', '1')
        } else {
            client.publish('PTIT/IoTN1/servo', '0')
        }
    });

    socket.on('control_relay_2', function (state2) {
        if (state2 == '1') {
            client.publish('PTIT/IoTN1/mode', '1')
        } else {
            client.publish('PTIT/IoTN1/mode', '0')
        }
    });
});